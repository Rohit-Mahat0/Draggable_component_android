package in.sis.widget.sfbuddy;

import static in.sis.widget.sfbuddy.R.*;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class FloatingWidgetService extends Service {
    public static final String CHANNEL_ID = "FloatingWidgetServiceChannel";
    private WindowManager windowManager;
    private View floatingWidget;
    private int initialX;
    private int initialY;
    private float initialTouchX;
    private float initialTouchY;
    private GestureDetector gestureDetector;
    private long downTime;
    private boolean isLongPress = false;
    private static final int CLICK_THRESHOLD = 500; // Milliseconds for click duration

    @Override
    public IBinder onBind(Intent intent) {
        return null; // We are not binding to this service
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // Create notification channel and notification
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Floating Widget Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Floating Widget")
                .setContentText("Service is running")
                .setSmallIcon(R.drawable.floating_widget_background)
                .build();
        startForeground(1, notification); // Start service in the foreground
        // Initialize your floating widget
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        floatingWidget = LayoutInflater.from(this).inflate(R.layout.floating_widget, null);
        // Set up layout parameters
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT; // Set initial position
        params.x = 0;
        params.y = 100;
        // Add the view to the window
        windowManager.addView(floatingWidget, params);
        // Set up button click listener
        ImageView floatingButton = floatingWidget.findViewById(R.id.floating_button);

        // Create GestureDetector
        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public void onLongPress(MotionEvent e) {
                // Start dragging
                Log.d("FloatingWidgetService", "Long press detected");
                showToast("Floating Button Drag!");
                startDrag(params, e);
//                return true;
            }
        });

        // Set up touch listener
        floatingWidget.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // Pass the touch events to the GestureDetector
                return gestureDetector.onTouchEvent(event);
            }
        });
    }

    private void startDrag(WindowManager.LayoutParams params, MotionEvent event) {
        // Get initial touch position
        initialX = params.x;
        initialY = params.y;
        initialTouchX = event.getRawX();
        initialTouchY = event.getRawY();

        // Move widget based on touch events
        floatingWidget.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Log.d("FloatingWidget", "ACTION_DOWN");
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        downTime = System.currentTimeMillis();
                        isLongPress = false; // Reset long press flag
                        return true; // Event handled

                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - initialTouchX;
                        float dy = event.getRawY() - initialTouchY;
                        Log.d("FloatingWidget", "ACTION_MOVE - dx: " + dx + ", dy: " + dy);
                        params.x = initialX + (int) dx;
                        params.y = initialY + (int) dy;
                        windowManager.updateViewLayout(floatingWidget, params);
                        return true; // Event handle
                    case MotionEvent.ACTION_UP:
                        long upTime = System.currentTimeMillis();
                        // Calculate the duration of the touch
                        long duration = upTime - downTime;

                        // Check if it's a short press
                        if (duration < CLICK_THRESHOLD) {
                            // Handle the click event
//                            Log.d("FloatingWidgetService", "Single Tap detected");
//                            showToast("Floating Button Clicked!");
                            callMenuAction(v);
                        } else {
                            // Handle long press or any other event
                            isLongPress = true; // Set long press flag
                        }
                        return true; // Consume the touch event
                }
                return false; // Event not handled
            }
        });
    }

    private void callMenuAction(View v) {
        // Create a PopupMenu
        PopupMenu popup = new PopupMenu(v.getContext(), v);
        // Inflate the menu resource file
        popup.getMenuInflater().inflate(R.menu.popup_menu, popup.getMenu());

        try {
            Field[] fields = popup.getClass().getDeclaredFields();
            for (Field field : fields) {
                if ("mPopup".equals(field.getName())) {
                    field.setAccessible(true);
                    Object menuPopupHelper = field.get(popup);
                    Class<?> classPopupHelper = Class.forName(menuPopupHelper
                            .getClass().getName());
                    Method setForceIcons = classPopupHelper.getMethod("setForceShowIcon", boolean.class);
                    setForceIcons.invoke(menuPopupHelper, true);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Set click listener for menu items
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();

//                if (id == R.id.action_one) {
//                    // Handle action for button 1
//                    return true;
//                } else if (id == R.id.action_two) {
//                    // Handle action for button 2
//                    return true;
//                } else if (id == R.id.action_three) {
//                    // Handle action for button 3
//                    return true;
//                } else {
//                    return false;
//                }
                return true;
            }
        });

        // Show the PopupMenu
        popup.show();
    }


    private void showToast(String message) {
        new Handler(Looper.getMainLooper()).post(() -> {
            Toast.makeText(FloatingWidgetService.this, message, Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingWidget != null) windowManager.removeView(floatingWidget);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY; // Keep the service running
    }

//    public Bitmap takeScreenshot() {
//        // Get the root view of the current screen
//        View rootView = getWindow().getDecorView().getRootView();
//
//        // Enable drawing cache and build it
//        rootView.setDrawingCacheEnabled(true);
//        rootView.buildDrawingCache(true);
//
//        // Create a bitmap from the cache
//        Bitmap bitmap = Bitmap.createBitmap(rootView.getDrawingCache());
//
//        // Disable drawing cache
//        rootView.setDrawingCacheEnabled(false);
//
//        return bitmap;
//    }
}




