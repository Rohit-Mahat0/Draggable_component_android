package in.sis.widget.sfbuddy;

import static in.sis.widget.sfbuddy.ScreenshotActivity.REQUEST_SCREENSHOT;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.snackbar.Snackbar;

import in.sis.widget.sfbuddy.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int REQUEST_OVERLAY_PERMISSION = 100;
    private static final int REQUEST_MEDIA_PROJECTION_PERMISSIONS = 101;

    private AppBarConfiguration appBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            Log.d(TAG, "onCreate: Checking overlay permissions");
            checkOverlayPermission();

            Log.d(TAG, "onCreate: Inflating layout");
            in.sis.widget.sfbuddy.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());

            setSupportActionBar(binding.toolbar);

            Log.d(TAG, "onCreate: Setting up Navigation Controller");
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
            appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
            NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

            binding.fab.setOnClickListener(view -> {
                Log.d(TAG, "onCreate: FAB clicked");
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAnchorView(R.id.fab)
                        .setAction("Action", null).show();
            });

            Button startWidgetButton = findViewById(R.id.startFloatingWidget);
            startWidgetButton.setOnClickListener(v -> {
                Log.d(TAG, "Start Widget Button clicked");
                checkMediaProjectionPermission();
            });

        } catch (Exception e) {
            Log.e(TAG, "Error in onCreate: ", e);
            Toast.makeText(this, "Error initializing the application", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkOverlayPermission() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Log.d(TAG, "Requesting overlay permission");
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
            } else {
                Log.d(TAG, "Overlay permission already granted");
                startFloatingWidgetService();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in checkOverlayPermission: ", e);
        }
    }

    private void checkMediaProjectionPermission() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) { // API 34+
                Log.d(TAG, "Checking Media Projection permission");
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{
                            Manifest.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION,
                            Manifest.permission.CAPTURE_AUDIO_OUTPUT,
                            Manifest.permission.RECORD_AUDIO
                    }, REQUEST_MEDIA_PROJECTION_PERMISSIONS);
                } else {
                    Log.d(TAG, "Media Projection permission already granted");
                    startFloatingWidgetService();
                }
            } else {
                Log.d(TAG, "Skipping Media Projection permission check for older API versions");
                startFloatingWidgetService();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in checkMediaProjectionPermission: ", e);
        }
    }

    private void startFloatingWidgetService() {
        try {
            Log.d(TAG, "Starting Floating Widget Service");
            Intent intent = new Intent(this, FloatingWidgetService.class);
            startService(intent);
        } catch (Exception e) {
            Log.e(TAG, "Error starting FloatingWidgetService: ", e);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == REQUEST_SCREENSHOT) {
                if (resultCode == RESULT_OK) {
                    Log.d(TAG, "Screen capture permission granted");
                    Intent serviceIntent = new Intent(this, FloatingWidgetService.class);
                    serviceIntent.putExtra("RESULT_CODE", resultCode);
                    serviceIntent.putExtra("DATA_INTENT", data);
                    startService(serviceIntent);
                } else {
                    Log.w(TAG, "Screen capture permission denied");
                    Toast.makeText(this, "Permission denied for screen capture", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in onActivityResult: ", e);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        try {
            if (requestCode == REQUEST_MEDIA_PROJECTION_PERMISSIONS) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "Media Projection permission granted");
                    startFloatingWidgetService();
                } else {
                    Log.w(TAG, "Media Projection permission denied");
                    Toast.makeText(this, "Media Projection permission is required", Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in onRequestPermissionsResult: ", e);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        try {
            getMenuInflater().inflate(R.menu.menu_main, menu);
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error in onCreateOptionsMenu: ", e);
            return false;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        try {
            int id = item.getItemId();
            if (id == R.id.action_settings) {
                Log.d(TAG, "Settings option selected");
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in onOptionsItemSelected: ", e);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        try {
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
            return NavigationUI.navigateUp(navController, appBarConfiguration) || super.onSupportNavigateUp();
        } catch (Exception e) {
            Log.e(TAG, "Error in onSupportNavigateUp: ", e);
            return false;
        }
    }
}
