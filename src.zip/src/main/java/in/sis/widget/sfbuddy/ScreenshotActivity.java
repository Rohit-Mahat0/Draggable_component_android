package in.sis.widget.sfbuddy;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.ByteBuffer;

public class ScreenshotActivity extends AppCompatActivity {
    public static final String TAG = "ScreenshotActivity";
    public static final int REQUEST_SCREENSHOT = 1001;

    private MediaProjectionManager mediaProjectionManager;
    private MediaProjection mediaProjection;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;

    private Handler handler = new Handler(Looper.getMainLooper());
    private int screenWidth, screenHeight, screenDensity;

    private static FloatingWidgetService floatingWidgetService; // Reference to FloatingWidgetService

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            Log.d(TAG, "onCreate: Hiding floating widget and initializing metrics");
            hideFloatingWidget();
            initScreenMetrics();

            mediaProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            Log.d(TAG, "onCreate: Requesting screen capture permission");
            startActivityForResult(mediaProjectionManager.createScreenCaptureIntent(), REQUEST_SCREENSHOT);
        } catch (Exception e) {
            Log.e(TAG, "Error in onCreate: ", e);
            showFloatingWidget();
            finish();
        }
    }

    private void initScreenMetrics() {
        try {
            DisplayMetrics metrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(metrics);
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            screenDensity = metrics.densityDpi;
            Log.d(TAG, "Screen Metrics - Width: " + screenWidth + ", Height: " + screenHeight + ", Density: " + screenDensity);
        } catch (Exception e) {
            Log.e(TAG, "Error initializing screen metrics: ", e);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == REQUEST_SCREENSHOT && resultCode == RESULT_OK) {
                Log.d(TAG, "Screen capture permission granted, setting up MediaProjection");
                mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data);
                imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);

                virtualDisplay = mediaProjection.createVirtualDisplay("ScreenCapture",
                        screenWidth, screenHeight, screenDensity,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        imageReader.getSurface(), null, handler);

                handler.postDelayed(this::captureScreen, 500);
            } else {
                Log.w(TAG, "Screen capture permission denied");
                showFloatingWidget();
                finish();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in onActivityResult: ", e);
            showFloatingWidget();
            finish();
        }
    }

    private void captureScreen() {
        try {
            Log.d(TAG, "Capturing screen...");
            Image image = imageReader.acquireLatestImage();
            if (image != null) {
                Bitmap bitmap = convertImageToBitmap(image);
                image.close();
                showScreenshotDialog(bitmap);
                releaseResources();
            } else {
                Log.w(TAG, "Failed to capture screenshot, image is null");
                Toast.makeText(this, "Failed to capture screenshot", Toast.LENGTH_SHORT).show();
                showFloatingWidget();
                finish();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error capturing screen: ", e);
            showFloatingWidget();
            finish();
        }
    }

    private Bitmap convertImageToBitmap(Image image) {
        try {
            Log.d(TAG, "Converting Image to Bitmap");
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int width = image.getWidth();
            int height = image.getHeight();

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);
            return bitmap;
        } catch (Exception e) {
            Log.e(TAG, "Error converting image to bitmap: ", e);
            return null;
        }
    }

    private void showScreenshotDialog(Bitmap bitmap) {
        try {
            Log.d(TAG, "Showing screenshot in AlertDialog");
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            ImageView imageView = new ImageView(this);
            imageView.setImageBitmap(bitmap);
            builder.setView(imageView);
            builder.setPositiveButton("Close", (dialog, which) -> {
                showFloatingWidget();
                finish();
            });
            builder.setOnDismissListener(dialog -> showFloatingWidget());
            builder.show();
        } catch (Exception e) {
            Log.e(TAG, "Error showing screenshot dialog: ", e);
            showFloatingWidget();
        }
    }

    private void releaseResources() {
        try {
            Log.d(TAG, "Releasing MediaProjection resources");
            if (virtualDisplay != null) virtualDisplay.release();
            if (mediaProjection != null) mediaProjection.stop();
        } catch (Exception e) {
            Log.e(TAG, "Error releasing resources: ", e);
        }
    }

    private void hideFloatingWidget() {
        try {
            if (floatingWidgetService != null) {
                Log.d(TAG, "Hiding floating widget");
                floatingWidgetService.setFloatingWidgetVisibility(false);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error hiding floating widget: ", e);
        }
    }

    private void showFloatingWidget() {
        try {
            if (floatingWidgetService != null) {
                Log.d(TAG, "Showing floating widget");
                floatingWidgetService.setFloatingWidgetVisibility(true);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error showing floating widget: ", e);
        }
    }

}
