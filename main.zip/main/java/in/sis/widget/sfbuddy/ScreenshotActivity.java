package in.sis.widget.sfbuddy;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.nio.ByteBuffer;

public class ScreenshotActivity extends AppCompatActivity {
    private static final String TAG = "ScreenshotActivity";
    public static final int REQUEST_SCREENSHOT = 1001;

    private MediaProjectionManager mediaProjectionManager;
    private MediaProjection mediaProjection;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;
    private AlertDialog screenshotDialog;

    private Handler handler = new Handler(Looper.getMainLooper());
    private int screenWidth, screenHeight, screenDensity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            Log.d(TAG, "onCreate: Initializing screenshot capture");

            // Initialize screen metrics
            initScreenMetrics();

            // Initialize MediaProjection Manager
            mediaProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

            // Request screen capture permission
            startActivityForResult(
                    mediaProjectionManager.createScreenCaptureIntent(),
                    REQUEST_SCREENSHOT
            );
        } catch (Exception e) {
            Log.e(TAG, "Error in onCreate", e);
            finishActivity();
        }
    }

    private void initScreenMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        screenDensity = metrics.densityDpi;

        Log.d(TAG, "Screen Metrics - Width: " + screenWidth +
                ", Height: " + screenHeight +
                ", Density: " + screenDensity);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.d(TAG, "onActivityResult: Request Code = " + requestCode +
                ", Result Code = " + resultCode +
                ", Data is null: " + (data == null));

        if (requestCode == REQUEST_SCREENSHOT) {
            if (resultCode == RESULT_OK && data != null) {
                Log.d(TAG, "Screen capture permission granted");
                setupMediaProjection(data);
            } else {
                Log.w(TAG, "Screen capture permission denied");
                Toast.makeText(this, "Failed to retrieve permission data", Toast.LENGTH_SHORT).show();
                finishActivity();
            }
        } else {
            Log.w(TAG, "Unexpected request code: " + requestCode);
            finishActivity();
        }
    }

    private void setupMediaProjection(Intent data) {
        try {
            // Create MediaProjection
            mediaProjection = mediaProjectionManager.getMediaProjection(RESULT_OK, data);

            // Setup ImageReader
            imageReader = ImageReader.newInstance(
                    screenWidth,
                    screenHeight,
                    PixelFormat.RGBA_8888,
                    2
            );

            // Create Virtual Display
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "ScreenCapture",
                    screenWidth,
                    screenHeight,
                    screenDensity,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    handler
            );

            // Capture screenshot after a short delay
            handler.postDelayed(this::captureScreenshot, 500);
        } catch (Exception e) {
            Log.e(TAG, "Error setting up media projection", e);
            finishActivity();
        }
    }

    private void captureScreenshot() {
        try {
            Log.d(TAG, "Capturing screenshot...");

            Image image = imageReader.acquireLatestImage();
            if (image != null) {
                Bitmap bitmap = convertImageToBitmap(image);
                image.close();

                if (bitmap != null) {
                    showScreenshotPopup(bitmap);
                } else {
                    Log.w(TAG, "Failed to convert image to bitmap");
                    finishActivity();
                }
            } else {
                Log.w(TAG, "Failed to capture screenshot, image is null");
                finishActivity();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error capturing screenshot", e);
            finishActivity();
        }
    }

    private void showScreenshotPopup(Bitmap bitmap) {
        try {
            // Dismiss any existing dialog
            if (screenshotDialog != null && screenshotDialog.isShowing()) {
                screenshotDialog.dismiss();
            }

            // Create new dialog
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            ImageView imageView = new ImageView(this);

            // Adjust image scaling and display
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);

            // Get screen dimensions
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            int screenWidth = displayMetrics.widthPixels;
            int screenHeight = displayMetrics.heightPixels;

            // Scale bitmap to fit screen while maintaining aspect ratio
            Bitmap scaledBitmap = Bitmap.createScaledBitmap(
                    bitmap,
                    screenWidth,
                    (int)(bitmap.getHeight() * ((float)screenWidth / bitmap.getWidth())),
                    true
            );

            imageView.setImageBitmap(scaledBitmap);

            builder.setView(imageView);
            builder.setPositiveButton("Close", (dialog, which) -> finishActivity());

            // Ensure dialog is shown on the main thread
            runOnUiThread(() -> {
                screenshotDialog = builder.create();
                screenshotDialog.setOnDismissListener(dialog -> finishActivity());

                // Adjust dialog window to match screen size
                screenshotDialog.show();
                screenshotDialog.getWindow().setLayout(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT
                );
            });
        } catch (Exception e) {
            Log.e(TAG, "Error showing screenshot popup", e);
            finishActivity();
        }
    }

    private Bitmap convertImageToBitmap(Image image) {
        try {
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();

            int width = image.getWidth();
            int height = image.getHeight();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * width;

            Bitmap bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
            );
            bitmap.copyPixelsFromBuffer(buffer);

            // Crop out any padding
            if (rowPadding > 0) {
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height);
            }

            return bitmap;
        } catch (Exception e) {
            Log.e(TAG, "Error converting image to bitmap", e);
            return null;
        }
    }

    private void releaseResources() {
        try {
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }

            if (mediaProjection != null) {
                mediaProjection.stop();
                mediaProjection = null;
            }

            if (imageReader != null) {
                imageReader.close();
                imageReader = null;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error releasing resources", e);
        }
    }

    private void finishActivity() {
        try {
            // Release resources
            releaseResources();

            // Dismiss dialog if showing
            if (screenshotDialog != null && screenshotDialog.isShowing()) {
                screenshotDialog.dismiss();
            }

            // Finish the activity
            finish();
        } catch (Exception e) {
            Log.e(TAG, "Error finishing activity", e);
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releaseResources();
    }
}