package in.sis.widget.sfbuddy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

public class FloatingWidgetService extends Service {
    public static final String TAG = "FloatingWidgetService";
    public static final String CHANNEL_ID = "FloatingWidgetServiceChannel";
    private WindowManager windowManager;
    private View floatingWidget;
    private int initialX, initialY;
    private float initialTouchX, initialTouchY;
    private GestureDetector gestureDetector;
    private long downTime;
    private boolean isLongPress = false;
    private static final int CLICK_THRESHOLD = 500;

    @Override
    public IBinder onBind(Intent intent) {
        return null; // No binding in this service
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Service onCreate: Checking overlay permission");

        // Check overlay permission
        if (!hasOverlayPermission()) {
            requestOverlayPermission();
            stopSelf();
            return;
        }

        // Create notification channel
        createNotificationChannel();

        // Build the notification for the foreground service
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Floating Widget")
                .setContentText("Service is running")
                .setSmallIcon(R.drawable.floating_widget_background)
                .setOngoing(true) // Ensures the notification cannot be swiped away
                .build();

        // Start foreground service with proper service type
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, notification);
        }

        setupFloatingWidget();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, // Unique ID for the channel
                    "Floating Widget Service", // Channel name (user-facing)
                    NotificationManager.IMPORTANCE_LOW // Notification importance
            );
            channel.setDescription("This channel is used for the Floating Widget Service.");

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    // Permission handler
    private boolean hasOverlayPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private void requestOverlayPermission() {
        Intent permissionIntent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
        permissionIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(permissionIntent);
        Toast.makeText(this, "Please enable 'Display Over Other Apps' permission.", Toast.LENGTH_LONG).show();
    }

    private void setupFloatingWidget() {
        try {
            Log.d(TAG, "Setting up floating widget");

            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            floatingWidget = LayoutInflater.from(this).inflate(R.layout.floating_widget, null);

            // Updated overlay type selection for Android 14
            int overlayType;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                overlayType = WindowManager.LayoutParams.TYPE_PHONE;
            }

            // Enhanced LayoutParams with compatibility flags
            final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, // Added for better compatibility
                    PixelFormat.TRANSLUCENT);

            params.gravity = Gravity.TOP | Gravity.LEFT;
            params.x = 0;
            params.y = 100;

            windowManager.addView(floatingWidget, params);

            ImageView floatingButton = floatingWidget.findViewById(R.id.floating_button);
            setupTouchListeners(params);

        } catch (Exception e) {
            Log.e(TAG, "Error in setupFloatingWidget: ", e);
        }
    }

    private void setupTouchListeners(WindowManager.LayoutParams params) {
        try {
            Log.d(TAG, "Setting up touch listeners");

            gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public void onLongPress(MotionEvent e) {
                    Log.d(TAG, "Long press detected");
                    showToast("Floating Button Drag!");
                    startDrag(params, e);
                }
            });

            floatingWidget.setOnTouchListener((v, event) -> gestureDetector.onTouchEvent(event));
        } catch (Exception e) {
            Log.e(TAG, "Error in setupTouchListeners: ", e);
        }
    }

    private void startDrag(WindowManager.LayoutParams params, MotionEvent event) {
        try {
            Log.d(TAG, "Starting widget drag");

            initialX = params.x;
            initialY = params.y;
            initialTouchX = event.getRawX();
            initialTouchY = event.getRawY();

            floatingWidget.setOnTouchListener((v, motionEvent) -> {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        Log.d(TAG, "Drag ACTION_DOWN");
                        downTime = System.currentTimeMillis();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (motionEvent.getRawX() - initialTouchX);
                        params.y = initialY + (int) (motionEvent.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingWidget, params);
                        return true;

                    case MotionEvent.ACTION_UP:
                        long duration = System.currentTimeMillis() - downTime;
                        if (duration < CLICK_THRESHOLD) {
                            Log.d(TAG, "Short press detected");
                            callMenuAction(v);
                        }
                        return true;
                }
                return false;
            });
        } catch (Exception e) {
            Log.e(TAG, "Error in startDrag: ", e);
        }
    }

    private void callMenuAction(View v) {
        try {
            Log.d(TAG, "Showing popup menu");

            PopupMenu popup = new PopupMenu(v.getContext(), v);
            popup.getMenuInflater().inflate(R.menu.popup_menu, popup.getMenu());

            popup.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.new_game) {
                    Log.d(TAG, "Menu: Report an Issue selected");
                    setFloatingWidgetVisibility(false); // Hide widget before starting screenshot
                    launchScreenshotActivity();
                    return true;
                } else if (item.getItemId() == R.id.help) {
                    Log.d(TAG, "Menu: DMS Utility selected");
                    showToast("DMS Utility Clicked");
                    return true;
                }
                return false;
            });

            popup.show();
        } catch (Exception e) {
            Log.e(TAG, "Error in callMenuAction: ", e);
        }
    }

    private void launchScreenshotActivity() {
        try {
            Log.d(TAG, "Launching ScreenshotActivity");
            Intent intent = new Intent(this, ScreenshotActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Optional: Add a flag to indicate this is a screenshot request
            intent.putExtra("SCREENSHOT_REQUEST", true);

            startActivity(intent);

            // Restore widget visibility after some time
            new Handler(Looper.getMainLooper()).postDelayed(() -> setFloatingWidgetVisibility(true), 3000);
        } catch (Exception e) {
            Log.e(TAG, "Error in launchScreenshotActivity: ", e);
        }
    }

    private void showToast(String message) {
        try {
            new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
        } catch (Exception e) {
            Log.e(TAG, "Error in showToast: ", e);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            if (floatingWidget != null) {
                windowManager.removeView(floatingWidget);
                Log.d(TAG, "Floating widget removed");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in onDestroy: ", e);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("SCREEN_CAPTURE_INTENT")) {
            Intent screenCaptureIntent = intent.getParcelableExtra("SCREEN_CAPTURE_INTENT");
            // Process screen capture intent if needed
            Log.d(TAG, "Received screen capture intent in service");
        }
        return START_STICKY;
    }

    public void setFloatingWidgetVisibility(boolean visible) {
        try {
            if (floatingWidget != null) {
                floatingWidget.setVisibility(visible ? View.VISIBLE : View.GONE);
                Log.d(TAG, "Floating widget visibility set to: " + (visible ? "VISIBLE" : "GONE"));
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in setFloatingWidgetVisibility: ", e);
        }
    }
}
